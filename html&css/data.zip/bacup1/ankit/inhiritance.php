<?php
class absence{

    function __construct($name,$mname,$lname,$salary)
    {
         $this->name =$name;
         $this->mname =$mname;
         $this->lname =$lname;
         $this->salary =$salary;

    }

    public function gas(){
        echo "this is inside parent class<br>";
        echo "first Name = ".$this->name."<br>";
        echo "Salary = ";
        echo $this->salary;
        echo "<br><br><br>";
    }
}

class present extends absence
{
    public $insentive = 2300;

    public function gas()
    {

        echo "This is for Child Class <br>";
        echo "first Name = ".$this->name."<br>";
        echo "Middle Name = ".$this->mname."<br>";
        echo "Last Name = ".$this->lname."<br>";
        echo "Salary and insentive = ";
        echo $this->ok = $this->salary + $this->insentive;

    }
}
$dev =new absence("Ankit","R","RAJKUMAR",10000);
$dev_2 =new present("Amit","R","RAJKUMAR",10000);
$dev->gas();
$dev->gas();
$dev_2->gas();
