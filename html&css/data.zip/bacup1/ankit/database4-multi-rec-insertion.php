<?php
$servername = "localhost";
$username = "root";
$password ="";
$dbname ="oscoffice";

$conn = new mysqli($servername,$username,$password,$dbname);

if($conn->connect_error){
    die("Connection Faild: ".$conn->connect_error);
}

#ISERTION QUERY I.S DATA INSERTING multiple records INTO DATA BASE


$sql = "INSERT INTO mydataa(roll,firstname,lastname,email) VALUES (15,'ANIL','PRAJAPATI','ANIL@exp.com')";


if ($conn->multi_query($sql) === TRUE){
    echo "multiple rercords are inserted by me";
}
else{
    echo "Error: ".$sql."<br><br>".$conn->error;
}
$conn->close();
?>