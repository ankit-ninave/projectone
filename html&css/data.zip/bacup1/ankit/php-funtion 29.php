<?php
declare(strict_types=1);
echo "<h2>function Declaration</h2>";

function firtfucn()
{
    echo "hello world<br>";
}
firtfucn();

echo "<h2>Passing doubble argumnet to a function</h2>";
function mysecond($name,$name2){
    echo "Hello $name good morning have nice day god  $name2 you<br>";
}
mysecond("ankit","bless");


echo "<h2>Passing tripple argumnet to a function</h2>";

function myfirst($name,$name2,$name3){
    echo "Hello $name good morning have nice day god  $name2 you $name3<br>";
}
myfirst("ankit","bless", "marry-farry");

?>