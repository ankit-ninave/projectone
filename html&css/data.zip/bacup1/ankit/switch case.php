<?php
echo "<br><h2> Switch case-1</h2>";
$today = date("l");
switch($today){
    case "mon":
        echo "today is monday go to office";
        break;
    case "tue":
        echo "today is monday go to office";
        break;
    case "wed":
        echo "today is monday go to office";
        break;
    case "thu":
        echo "today is thus go to office and buy some food";
        break;
    case "fri":
        echo "today is friday go to office and do your work";
        break;
    case "sat":
        echo "today is saturday go for dinner";
        break;
    case "sun":
        echo "watch movie or go for outing";
        break;
    default:
        echo "No information available for that day.";
        break;
}
echo "<br><h3> Switch case-2</h3>";
$color = "red";
switch($color){
    case "red":
    echo "color is red";
    break;

    case "yellow":
    echo "today is yellow day";
    break;

    case "blue":
    echo "today is yellow day";
    break;

    default:
    echo "No information available for that day.";
    break;
}
echo "<br><h3> Switch case-3</h3>";
$age = 15;
switch ($age){
    case 14:
        echo "you are 14 years old";
        break;
    case 15:
     echo "you are 15 years old";
     break;

    case 16:
    echo "you are 16 years old";
    break;

    case 17:
        echo "you are 18 years old";
        break;

    case 18:
        echo "you are 18 years old";
        break;

    case 19:
    echo "you are 19 year old";
    break;

    case 20:
      echo "your age is 20 years old;";
      break;

    default:
        echo "you are adult now";
        break;

}
?>
