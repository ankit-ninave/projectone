<?php
echo "connecting data base<br>";
$servername = "localhost";
$username = "root";
$password ="";
$dbname = "oscoffice";
$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn){
    die("we are faild to connect:".mysqli_connect_error());
}
echo "Connection was successful";


$sql ="CREATE TABLE officeEMP(roll INT (6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
email VARCHAR(50))";






if ($conn->query($sql) === TRUE) {
    echo "Table MyGuests created successfully";
} else {    echo "Error creating table: " . $conn->error;
}


$conn->close();
?>