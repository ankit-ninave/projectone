<?php
echo "<h2>first interface program</h2>";

interface A{
    function go($xx,$yy);   #acces modifiars are not specified by deafult is public
}                           #but cannt give private and public alos where methods are
                            #not implemented
interface B{
    function goa($xy,$yx);

}

class C implements A,B{                    #implment keyword is used instead of extend
    function  go($xx,$yy){                  #using commaa opartaor we can define multiple
        echo "I am first interface of go :-";      #interface
        echo $xx + $yy;
        echo "<br>";
    }
    function goa($xy,$yx){
        echo "I am second interface of goa :-";
        echo $xy + $yx;
        echo "<br>";

    }
    function gone($xyz,$yxz){
        echo "I am third interface of gone :-";
        echo $xyz + $yxz;
        echo "<br>";

    }
}

$threehero = new C();
$threehero->go(800,500);
$threehero->goa(101,101);
$threehero->gone(1020,1020);