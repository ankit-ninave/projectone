<html>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "oscoffice";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

if(isset($_POST['submit'])) {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email=$_POST['email'];
    $mysqli->query("INSERT INTO mydataa(firstname,lastname,email)values('$firstname','$lastname','$email')") or
    die($mysqli->error);
}