<?php
class arithematic{
	public $a;
    public $b;
    public $c;
    public function add(){
     $this->c = $this->a + $this->b;
     return $this->c;
    }
     public function sub(){
        $this->c = $this->a - $this->b;
        return $this->c;
    }
    public function multi(){
        $this->c = $this->a * $this->b;
        return $this->c;
    }
    public function divi(){
        $this->c = $this->a / $this->b;
        return $this->c;
    }
 }
$callme = new arithematic();
$callme->a =10;
$callme->b =20;
echo "Additon =".$callme->add();
echo "<br>";
echo "Subtraction =".$callme->sub();
echo "<br>";
echo "Multiplication =" .$callme->multi();
echo "<br>";
echo "Division =" .$callme->multi();
echo "<br>";
/*notice that same funtion but work differt work for differt objects (callme,and callme_2)
and we can also change the value of a and be*/
$callme_2 = new arithematic();
$callme_2->a =90;
$callme_2->b =210;
echo "Additon =".$callme_2->add();

?>

