<?php
echo "connecting data base<br>";
$servername = "localhost";
$username = "root";
$password ="";

$conn = mysqli_connect($servername,$username,$password);

if(!$conn){
    die("we are faild to connect:".mysqli_connect_error());
}
echo "Connection was successful<br>";


echo "<br>for createing data base<br>";
$sql = "CREATE DATABASE oscoffice";

if($conn->query($sql)== TRUE){
    echo "database is created sucessfully";
}
else {
    echo "error creating database:".$conn->error;
}


$conn->close();
