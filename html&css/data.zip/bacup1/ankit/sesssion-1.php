<?php

session_start();
$_SESSION['username'] = "ankit";
$_SESSION['favcat'] = "books";
echo "your session is saved";
?>