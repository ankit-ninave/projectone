<?php

session_start();
if(isset($_SESSION['username'])){
    echo "welcome ".$_SESSION['username'];
    echo "<br> your fav cat is ".$_SESSION['favcat'];
    echo "<br>";
}
else{
    echo "Please login";
}