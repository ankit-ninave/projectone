<?php
 abstract class parentclasss{
     protected function method1($a,$b){}  #method name should be same
                                          # must contain body {}

 }

 class childclass extends parentclasss{
     public function method1($a, $b)               #method name should be same
     {
         // TODO: Implement method1() method
         echo $a + $b;

     }
     public function get()                         #own methods
     {
         echo "i am in 1st class";

     }
 }
class childclass_2 extends parentclasss{
    public function method1($a, $b)               #method name should be same
    {
        // TODO: Implement method1() method
        echo $a + $b;

    }
    public function set()                          #own methods
    {
        echo "i am in 2nd class";

    }
}
class childclass_3 extends parentclasss{

    public function method1($a, $b)               #method name should be same
    {
        // TODO: Implement method1() method
        echo $a + $b;

    }
    public function go()                           #own methods
    {
        echo "i am in 3rd class";

    }
}
/*multiple object declaration of different child class */
#notic that here we can`t create abstract class object
 $obj = new childclass();
 echo $obj->get();
 echo $obj->method1(10,210);
 echo "<br>";

$obj = new childclass_2();
echo $obj->set();
echo $obj->method1(220,210);
echo "<br>";

$obj = new childclass_3();
echo $obj->go();
echo $obj->method1(320,210);
echo "<br>";