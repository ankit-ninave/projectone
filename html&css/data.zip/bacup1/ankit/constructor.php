<?php
/*
class school{
    public $name;
    public $age;
    function flask()
    {
        echo $this->name;
        echo $this->age;
    }
}
$obj = new school();
$obj->name ="ankit";
$obj->age =15;
$obj->flask();

*/
class office{
    public $name;
    public $age;
    public $salary;
    function __construct($name,$age,$salary)
    {
        $this->name =$name;
        $this->age =$age;
        $this->salary =$salary;
        echo "Eployee Name is:-".$name."<br>"."Eployee age is:-".$age."<br>"."Eployee salary is:-".$salary;
        echo "<br><br>";

    }
}
$obj = new office("Afreen Khan ",29,33000);
$obj_1 = new office("Akhilesh Indurkar",25,32000);
$obj_2 = new office("Akshay Kothekar",35,39000);
$obj_3 = new office("Amreen Rahemaan",32,34000);
$obj_4 = new office("Anup Mavale",33,40000);

