<?php
$cat = $_COOKIE['category'];
 echo "here are the all cookies $cat";

 ?>