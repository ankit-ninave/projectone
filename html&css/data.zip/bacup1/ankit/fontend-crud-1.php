<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CRUD</title>
</head>
<body>
        <form action="backend-curd.php" method="post">
            <label>ROLL NO</label>
            <input type="number" name="rollno" min="1" max="15" ><br>
            <label>NAME</label>
            <input type="text" name="firstname"><br>
            <label>LAST NAME</label>
            <input type="text" name="lastname"><br>
            <label>E-MAIL</label>
            <input type="email" name ="email"><br>
            <input type="submit" name="submit">
        </form>
</body>
</html>