<?php
echo "<h2>Index array</h2>";
echo "<br>Array is collection of homogeneos type of element<br>";

$bikes = array("kawasaki","Ktm","hornet");
   echo "Total number of array is ".count($bikes);  #count funtion to count the

   echo "<p>printing index array without loop</p>";
   echo "$bikes[0]<br>";
   echo "$bikes[1]<br>";
   echo "$bikes[2]<br>";
echo "<p>printing index array with foreach loop</p>";
$length =count($bikes);

for ($i=0; $i < $length; $i++){
 echo "$bikes[$i]";
    echo "<br>";

}