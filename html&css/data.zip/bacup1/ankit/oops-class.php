<?php
class Books{
    public $la;
    public $lo;
    public $lues;
   function __construct($la,$lo){
        echo "Drupal book";
        echo $la;
        echo $lo;
        echo "<br>";
        return $this->lues = $this->la + $this->lo;
        echo "Calculation of two number = ";
    }

}
//To create php object we have to use a  new operator. Here php object is the object of the Books Class
$obj = new Books("10","20");

/*class Books{
    public function name($num){
        echo "Drupal book".$num;
    }
    public function price($name){
        echo "900 Rs/-".$name;
    }
}
//To create php object we have to use a  new operator. Here php object is the object of the Books Class.
$obj = new Books();
$obj->name(10);
$obj->price("only");
?> */

?>