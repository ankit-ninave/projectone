<?php
echo "hello world<br>";
echo "<br>";
echo "<h2>first program</h2>";/*string print*/
echo "<br><h3>sum of number</h3><br>";
$a = 10;                      #sum of number
$b = 10;                      #integer
$txt = "ankit";               #string
$x = 1.5;                     #float
$c =$a + $b;
$d =$a - $b;
$e =$a / $b;
$f =$a * $b;
echo "Sum of two number is $c";
echo "<br>";
echo "Subtraction of two number is $d";
echo "<br>";
echo "Division of two number is $e";
echo "<br>";
echo "multiplication of two number is $f";
echo "<br>";



function first(){
    $a =1;                      #sum of number in fuction local variable scope
    $b =10;
    $c =$a + $b;
    echo "Sum of two number is $c";
}
first();
echo "<br>";
echo "Sum of two number is $c";
echo "<br>";
var_dump($a);
echo "<br>";
var_dump($txt);
echo "<br>";
var_dump($x);
echo "<br>";

#data types in php
/*
 * integer $x =10;
 * float   $a =10.5;
 * string  $text = "ankit";
 * boolean $true/false

* array  */
$abc =array("ankit","raj","jiganesh");
var_dump($abc);
echo "<br>";
echo $abc[2];
/* object
 * null $a =null
 *
 */
?>