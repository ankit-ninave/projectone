<?php
echo "<h2>Assosiative Array</h2>";

$parts =array("11" =>"Cpu","12" =>"monitor","13" =>"Mouse","14" =>"Headphones","15" =>"keyboards");
echo count($parts);
echo "<br>";
echo "today my". $parts['12'] ."and". $parts['14']."is not working";



foreach($parts as $x => $x_value) {
    echo "Key=" . $x . ", Value=" . $x_value;
    echo "<br>";
}

echo "<h2>Multidimensional Array</h2>";

echo "<p>collection array of array of array are know as multidimentional array</p>";

$ismart = array(
    array("ankit",'1500',"Devloper"),
    array("anil",'1700',"Devloper"),
    array("aashish",'1900',"Devloper"),
    );
echo $ismart[0][0].": Salary: ".$ismart[0][1].", Post: ".$ismart[0][2].".<br>";
echo $ismart[1][0].": Salary: ".$ismart[1][1].", Post: ".$ismart[1][2].".<br>";
echo $ismart[2][0].": Salary: ".$ismart[2][2].", Post: ".$ismart[2][2].".<br>";

sort($ismart);

