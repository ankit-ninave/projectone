<?php
echo "<h3>For loop</h3><br>";

for($x = 10;$x < 21;$x++){
    echo $x;
    echo "<br>";

}



echo "<h3>while loop</h3><br>";
$a = 0;
while ($a <= 10){
    echo "print the value is 10 *  $a";
    echo  "<br>";
    $a++;
}
/*
for($i=0; $i< 87;)    #infinite loop
{
    echo "$i";
}
*/
echo "<h3>do while loop</h3><br>";

$i = 100;
do{
    echo $i;
    echo "<br>";
    $i++;

}while($i < 20);


echo "<h3>foreach loop</h3><br>";

$fruits = array("Apple","Mango","banana","Pineapple","Bingo");

foreach($fruits as $value)
{
    echo"$value";
    echo "<br>";
}
echo "<h3>for loop using array</h3><br>";
for($i = 0;$i < 5; $i++)
{
    echo "$fruits[$i]";
    echo "<br>";
}

?>



























