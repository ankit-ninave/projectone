<?php

#if statement - executes some code if one condition is true
$a = 10;
$b = 15;
$x = 15;
$y = 15;
echo "<h3>if statment</h3><br>";                       # Condition-1

if($a < $b) {
    echo "a is equal to b";
}

echo "<br><h3>if else statment</h3><br>";               # Condition-2

if($a > $b) {
    echo "a is big";
}
    else{
        echo "b is big";  #this condition executes
}

echo "<br><h3>if elseif else statment</h3><br>";        # Condition-3

if($x > $y){
   echo "a is big";

}
elseif($x < $y)
{
    echo "b is big";
}
else{
    echo "they are equal";

}
                                                         #example

$age = 18;
if($age >= 25){
    echo "you can drive the car";
}
elseif ($age > 17) {
    echo "you are not eligible to drive the car";
}
else
    echo "don`t drive the car you are eligible";

$t = date("H");
echo "<p>The hour (of the server) is " . $t;
echo ", and will give the following message:</p>";

if ($t < "10") {
    echo "Have a good morning!";
} elseif ($t < "20") {
    echo "Have a good day!";
} else {
    echo "Have a good night!";
}
?>