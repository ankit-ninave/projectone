<?php
$servername = "localhost";
$username = "root";
$password ="";
$dbname ="oscoffice";

$conn = new mysqli($servername,$username,$password,$dbname);

if($conn->connect_error){
    die("Connection Faild: ".$conn->connect_error);
}

#ISERTION QUERY I.S DATA INSERTING INTO DATA BASE

$sql = "INSERT INTO mydataa(firstname,lastname,email) VALUES ('Praful','Shahu','praful@exp.com')";


if($conn->query($sql)== TRUE){
    echo "new rercord inserted by me";
}
else{
    echo "Error: ".$sql."<br><br>".$conn->error;
}
$conn->close();
?>