<?php

setcookie("category","cloths",time() +84600,"/");
echo "the cookie is set";

/* note: -cookie is not use to store user name and password,
A cookie is often used to identify a user. A cookie is a small file
that the server embeds on the user's computer. Each time the same computer
requests a page with a browser,it will send the cookie too. With PHP, you can
 both create and retrieve cookie values.

Cookie: Phpstorm-5a9375fa=f0cfb379-3da9-440f-b916-5cd10203ea60;
PHPSESSID=k1ldmf53d9ibutsq93ifhjof07; category=cloths
*/