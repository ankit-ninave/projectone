<?php
?
DELETE FROM `mydataa` WHERE `mydataa`.`roll` = 5;