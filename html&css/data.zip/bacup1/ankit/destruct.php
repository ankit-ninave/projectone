<?php
class office
{
    function __construct($name, $salary, $post)
    {
       $this ->name =$name;
       $this ->salary =$salary;
       $this ->post =$post;  #assigning values to post from $post
    }
    function __destruct()
    {
        echo $this->name;
        echo "<br>";
        echo $this->salary;
        echo "<br>";
        echo $this->post;
    }
}
$obj = new office("amit",100000,"devloper")
?>