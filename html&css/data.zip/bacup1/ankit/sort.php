<?php

echo "<h2>Sorting of arrays</h2>";

$employe = array("Wasim Varshani",
               "Manoj Pathode",
                "Kapil Borkar",
                "Bhagyeshri Khanzode",
                "Shubham Ghagare",
                "Archana Nagarkar",
                "Sanjay Purkam",
                "Pooja Harne");
$arraysize = count($employe);
echo "<br><h3>before asort</h3><br>";
for ($i = 0; $i < $arraysize; $i++)
{
    echo $employe[$i];
    echo "<br>";
}
echo "<br><h3>after asort asending order</h3><br>";
for ($i = 0; $i < $arraysize; $i++)
{
    sort($employe);
    echo $employe[$i];
    echo "<br>";
}
echo "<br><h3>after rsort decending order</h3><br>";
for ($i = 0; $i < $arraysize; $i++)
{
    rsort($employe);
    echo $employe[$i];
    echo "<br>";
}
echo "<br><h3>after asort acending value according to value</h3><br>";
$age = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");
arsort($age);
foreach($age as $x => $x_value) {
    echo "Key=" . $x . ", Value=" . $x_value;
    echo "<br>";
}