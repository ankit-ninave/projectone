<html>
<head>
<title>php</title>
</head>
<body>

<?php

abstract class car{
	public $name;
	public function __construct($name){
		$this->name=$name;
	}
	abstract public function intro();
}

//child classes
class Audi extends car{
	public function intro(){
		return "Choose German quality! I'm an $this->name!"; 
  }
}

class pmw extends car{
	public function intro(){
		return "Choose German quality! I'm an $this->name!"; 
	}
}


$audi = new audi( "Audi");
echo $audi->intro();
echo "<br>";

$pmw = new pmw("PMW");
echo $pmw->intro();
?>


</body>
</html>