<html>
<head>
<title>php</title>
</head>
<body>

<?php

echo(max(2,4,18,25));


?>


</body>
</html>