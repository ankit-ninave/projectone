<html>
<head>
<title>php</title>
</head>
<body>

<?php

class fruit{
	public $name;
	public $color;
	
	function __construct($name,$color){
		$this->name=$name;
		$this->color=$color;
	}
	
	function intro(){
		echo "The fruit is $this->name and color is $this->color.";
	}
	}
	
	class  stroberry extends fruit{
		public $weight;
		
		function __construct($weight){
		$this->weight=$weight;
		
	}
		
		function message(){
			echo "Am i a fruit or a berry? $this->weight";
		}
		}
	
$e1 = new stroberry ("apple","yellow");
$e2 = new stroberry ("50");


$e1->intro();
$e2->message();

?>


</body>
</html>