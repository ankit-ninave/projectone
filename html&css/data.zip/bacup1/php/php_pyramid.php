<html>
<head>
<title>php</title>
</head>
<body>

<?php


function pypart($n)
{
for($i = 0;$i<$n;$i++)
{
for($j = 0;$j<=$i; $j++)
{
echo "*";
}
echo "\n";
}
}
$n = 5;


?>


</body>
</html>