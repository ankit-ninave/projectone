<html>
<head>
<title>php</title>
</head>
<body>

<?php


abstract class parentclass{
	
	abstract protected function prefixName($name);
}

class childclass extends parentclass{
	public function prefixName($name){
		if ($name =="john Doe"){
			$prefix = "Mr.";
		}
		elseif ($name =="jane Doe"){
			$prefix = "Mrs.";
		}
		else{
			$prefix = "";
		}
		return "{$prefix}{$name}";
	}
	}
	
	$class = new childclass;
	echo $class->prefixName("john Doe");
	echo "<br>";
	
	echo $class->prefixName("jane Doe");
	
	
?>


</body>
</html>