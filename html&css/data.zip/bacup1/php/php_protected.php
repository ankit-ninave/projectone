<html>
<head>
<title>php</title>
</head>
<body>

<?php

public 
?>


</body>
</html>